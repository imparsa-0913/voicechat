package com.example.simplevoiceplugin;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.*;
import java.net.*;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class SimpleVoicePlugin extends JavaPlugin {

    private static class Info {
        String world, ip;
        double x, y, z;
        boolean canSpeak;
    }

    private static class Member {
        volatile SocketAddress addr;
        volatile long seen;
    }

    private DatagramSocket socket;
    private volatile boolean running;
    private volatile Map<String, Info> snapshot = new HashMap<String, Info>();
    private final Map<String, Member> members = new ConcurrentHashMap<String, Member>();

    private double maxDist;
    private boolean sameWorld, verifyIp;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        maxDist = getConfig().getDouble("proximity-distance", 0);
        sameWorld = getConfig().getBoolean("same-world-only", true);
        verifyIp = getConfig().getBoolean("verify-ip", true);

        try {
            InetAddress bind = InetAddress.getByName(getConfig().getString("bind-address", "0.0.0.0"));
            socket = new DatagramSocket(new InetSocketAddress(bind, getConfig().getInt("port", 24454)));
        } catch (Exception e) {
            getLogger().severe("Could not open UDP port: " + e);
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        // Player positions are read on the main thread, the network thread only reads the snapshot.
        Bukkit.getScheduler().runTaskTimer(this, new Runnable() {
            public void run() { updateSnapshot(); }
        }, 20L, 10L);

        running = true;
        Thread t = new Thread(new Runnable() {
            public void run() { receiveLoop(); }
        }, "SimpleVoice-relay");
        t.setDaemon(true);
        t.start();
        getLogger().info("Voice relay listening on UDP " + socket.getLocalPort());
    }

    @Override
    public void onDisable() {
        running = false;
        if (socket != null) socket.close();
    }

    private void updateSnapshot() {
        Map<String, Info> map = new HashMap<String, Info>();
        for (Player p : Bukkit.getOnlinePlayers()) {
            Info i = new Info();
            Location l = p.getLocation();
            i.world = l.getWorld().getName();
            i.x = l.getX();
            i.y = l.getY();
            i.z = l.getZ();
            i.ip = p.getAddress() != null ? p.getAddress().getAddress().getHostAddress() : "";
            i.canSpeak = p.hasPermission("simplevoice.speak");
            map.put(p.getName().toLowerCase(), i);
        }
        snapshot = map;
    }

    private boolean canHear(Info from, Info to) {
        if (sameWorld && !from.world.equals(to.world)) return false;
        if (maxDist > 0) {
            if (!from.world.equals(to.world)) return false;
            double dx = from.x - to.x, dy = from.y - to.y, dz = from.z - to.z;
            return dx * dx + dy * dy + dz * dz <= maxDist * maxDist;
        }
        return true;
    }

    private void receiveLoop() {
        byte[] buf = new byte[4096];
        long lastClean = System.currentTimeMillis();
        while (running) {
            try {
                DatagramPacket p = new DatagramPacket(buf, buf.length);
                socket.receive(p);
                long now = System.currentTimeMillis();

                DataInputStream in = new DataInputStream(new ByteArrayInputStream(p.getData(), 0, p.getLength()));
                if (in.readByte() != 1) continue;
                in.readUTF(); // room name from the client, ignored: the server itself is the room
                String name = in.readUTF();
                byte[] audio = new byte[in.available()];
                in.readFully(audio);

                String key = name.toLowerCase();
                Map<String, Info> snap = snapshot;
                Info me = snap.get(key);
                if (me == null) continue; // not an online player
                if (verifyIp && !p.getAddress().getHostAddress().equals(me.ip)) continue;

                Member m = members.get(key);
                if (m == null) {
                    m = new Member();
                    members.put(key, m);
                }
                m.addr = p.getSocketAddress();
                m.seen = now;

                if (audio.length == 0 || audio.length > 1400 || !me.canSpeak) continue;

                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                DataOutputStream out = new DataOutputStream(bo);
                out.writeByte(2);
                out.writeUTF(name);
                out.write(audio);
                byte[] data = bo.toByteArray();

                for (Map.Entry<String, Member> e : members.entrySet()) {
                    if (e.getKey().equals(key)) continue;
                    Info other = snap.get(e.getKey());
                    Member om = e.getValue();
                    if (other == null || now - om.seen > 10000) continue;
                    if (!canHear(me, other)) continue;
                    socket.send(new DatagramPacket(data, data.length, om.addr));
                }

                if (now - lastClean > 10000) {
                    lastClean = now;
                    Iterator<Map.Entry<String, Member>> it = members.entrySet().iterator();
                    while (it.hasNext()) {
                        Map.Entry<String, Member> e = it.next();
                        if (now - e.getValue().seen > 10000 || !snap.containsKey(e.getKey())) it.remove();
                    }
                }
            } catch (Exception ignored) {
                // socket closed or malformed packet
            }
        }
    }
}
